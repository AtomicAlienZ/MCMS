#SKD101|{kryzhani_cybuy}|50|2016.05.26 18:05:32|173|2|1|56|1|3|2|1|3|10|1|2|8|1|3|5|8|1|1|8|3|7|4|6|14|2|14|5|1

DROP TABLE IF EXISTS pm_banners;
CREATE TABLE `pm_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `file_url` varchar(255) NOT NULL DEFAULT '',
  `preview` varchar(255) NOT NULL DEFAULT '',
  `w_size` int(5) unsigned NOT NULL DEFAULT '0',
  `h_size` int(5) unsigned NOT NULL DEFAULT '0',
  `preference` int(11) NOT NULL DEFAULT '0',
  `type` int(1) unsigned NOT NULL DEFAULT '0',
  `enabled` int(1) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  `flash_menu` int(1) unsigned NOT NULL DEFAULT '0',
  `transparent_b` int(1) unsigned NOT NULL DEFAULT '0',
  `background` varchar(10) NOT NULL DEFAULT '',
  `quality` int(1) unsigned NOT NULL DEFAULT '0',
  `totalShow` int(11) unsigned NOT NULL DEFAULT '0',
  `useTotalShow` int(1) unsigned NOT NULL DEFAULT '0',
  `code` text NOT NULL,
  `showAfterPage` int(1) unsigned NOT NULL DEFAULT '0',
  `limitLife` int(1) unsigned NOT NULL DEFAULT '0',
  `limitLifeStart` date NOT NULL DEFAULT '0000-00-00',
  `limitLifeEnd` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `pm_banners` VALUES
(1, 1, 'Banner 1', 'content/banners_files/1464112577_1.jpg', 'content/banners_files/sm_1464112577_1.jpg', 1100, 300, 1, 1, 1, 'banner-1', 0, 0, '', 0, 0, 0, '', 0, 0, '0000-00-00', '0000-00-00'),
(2, 1, 'Banner 2', 'content/banners_files/1464112652_2.jpg', 'content/banners_files/sm_1464112652_2.jpg', 1100, 300, 1, 1, 1, 'banner-2', 0, 0, '', 0, 0, 0, '', 0, 0, '0000-00-00', '0000-00-00');

DROP TABLE IF EXISTS pm_banners_group;
CREATE TABLE `pm_banners_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lim` int(11) unsigned NOT NULL DEFAULT '0',
  `insert_mode` int(1) unsigned NOT NULL DEFAULT '0',
  `s_id` int(11) unsigned NOT NULL DEFAULT '0',
  `toc_id` int(11) unsigned NOT NULL DEFAULT '0',
  `zone_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `pm_banners_group` VALUES
(1, 5, 1, 1, 19, 1);

DROP TABLE IF EXISTS pm_banners_stat;
CREATE TABLE `pm_banners_stat` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `banner_id` int(11) unsigned NOT NULL DEFAULT '0',
  `operation` varchar(10) NOT NULL DEFAULT '',
  `user_ip` varchar(50) NOT NULL DEFAULT '',
  `dates` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `pm_banners_stat` VALUES
(1, 1, 'view', '91.227.180.139', '2016-05-24 20:58:03'),
(2, 1, 'view', '91.227.180.139', '2016-05-24 20:58:08'),
(3, 1, 'view', '91.227.180.139', '2016-05-24 20:58:09'),
(4, 1, 'view', '91.227.180.139', '2016-05-24 20:58:10'),
(5, 1, 'view', '91.227.180.139', '2016-05-24 20:59:05'),
(6, 1, 'view', '91.227.180.139', '2016-05-24 20:59:50'),
(7, 1, 'view', '91.227.180.139', '2016-05-24 21:00:00'),
(8, 1, 'view', '91.227.180.139', '2016-05-24 21:01:20'),
(9, 1, 'view', '91.227.180.139', '2016-05-24 21:01:47'),
(10, 2, 'view', '91.227.180.139', '2016-05-24 21:01:47'),
(11, 1, 'view', '91.227.180.139', '2016-05-24 21:04:53'),
(12, 2, 'view', '91.227.180.139', '2016-05-24 21:04:53'),
(13, 1, 'view', '91.227.180.139', '2016-05-24 21:04:53'),
(14, 2, 'view', '91.227.180.139', '2016-05-24 21:04:53'),
(15, 1, 'view', '91.227.180.139', '2016-05-24 21:04:53'),
(16, 2, 'view', '91.227.180.139', '2016-05-24 21:04:53'),
(17, 1, 'view', '91.227.180.139', '2016-05-24 21:04:54'),
(18, 2, 'view', '91.227.180.139', '2016-05-24 21:04:54'),
(19, 1, 'view', '91.227.180.139', '2016-05-24 21:04:54'),
(20, 2, 'view', '91.227.180.139', '2016-05-24 21:04:54'),
(21, 1, 'view', '91.227.180.139', '2016-05-24 21:05:16'),
(22, 2, 'view', '91.227.180.139', '2016-05-24 21:05:16'),
(23, 1, 'view', '91.227.180.139', '2016-05-24 21:06:09'),
(24, 2, 'view', '91.227.180.139', '2016-05-24 21:06:09'),
(25, 1, 'view', '91.227.180.139', '2016-05-24 21:06:10'),
(26, 2, 'view', '91.227.180.139', '2016-05-24 21:06:10'),
(27, 1, 'view', '91.227.180.139', '2016-05-24 21:06:23'),
(28, 2, 'view', '91.227.180.139', '2016-05-24 21:06:23'),
(29, 1, 'view', '91.227.180.139', '2016-05-24 21:06:39'),
(30, 2, 'view', '91.227.180.139', '2016-05-24 21:06:39'),
(31, 1, 'view', '91.227.180.139', '2016-05-24 21:07:10'),
(32, 2, 'view', '91.227.180.139', '2016-05-24 21:07:10'),
(33, 1, 'view', '91.227.180.139', '2016-05-24 21:07:12'),
(34, 2, 'view', '91.227.180.139', '2016-05-24 21:07:12'),
(35, 1, 'view', '91.227.180.139', '2016-05-24 21:07:32'),
(36, 2, 'view', '91.227.180.139', '2016-05-24 21:07:32'),
(37, 1, 'view', '91.227.180.139', '2016-05-24 21:08:20'),
(38, 2, 'view', '91.227.180.139', '2016-05-24 21:08:20'),
(39, 1, 'view', '91.227.180.139', '2016-05-24 21:09:11'),
(40, 2, 'view', '91.227.180.139', '2016-05-24 21:09:11'),
(41, 1, 'view', '91.227.180.139', '2016-05-24 21:09:28'),
(42, 2, 'view', '91.227.180.139', '2016-05-24 21:09:28'),
(43, 1, 'view', '91.227.180.139', '2016-05-24 21:10:24'),
(44, 2, 'view', '91.227.180.139', '2016-05-24 21:10:24'),
(45, 1, 'view', '91.227.180.139', '2016-05-24 21:11:08'),
(46, 2, 'view', '91.227.180.139', '2016-05-24 21:11:08'),
(47, 1, 'view', '91.227.180.139', '2016-05-24 21:17:19'),
(48, 2, 'view', '91.227.180.139', '2016-05-24 21:17:19'),
(49, 1, 'view', '91.227.180.139', '2016-05-25 12:31:01'),
(50, 2, 'view', '91.227.180.139', '2016-05-25 12:31:01'),
(51, 1, 'view', '91.227.180.139', '2016-05-25 12:31:08'),
(52, 2, 'view', '91.227.180.139', '2016-05-25 12:31:08'),
(53, 1, 'view', '91.227.180.139', '2016-05-26 18:04:44'),
(54, 2, 'view', '91.227.180.139', '2016-05-26 18:04:44'),
(55, 1, 'view', '91.227.180.139', '2016-05-26 18:05:10'),
(56, 2, 'view', '91.227.180.139', '2016-05-26 18:05:10');

DROP TABLE IF EXISTS pm_banners_zones;
CREATE TABLE `pm_banners_zones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `w_size` int(5) unsigned NOT NULL DEFAULT '0',
  `h_size` int(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `pm_banners_zones` VALUES
(1, 'Top', 100, 100);

DROP TABLE IF EXISTS pm_catalog;
CREATE TABLE `pm_catalog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `type` enum('folder','item') NOT NULL DEFAULT 'item',
  `alias` varchar(30) NOT NULL DEFAULT '',
  `relative_url` varchar(255) NOT NULL DEFAULT '',
  `full_relative_url` varchar(255) NOT NULL DEFAULT '',
  `fieldset` varchar(30) NOT NULL DEFAULT '',
  `img` varchar(255) NOT NULL DEFAULT '',
  `img_sm` varchar(255) NOT NULL DEFAULT '',
  `img_sm1` varchar(255) NOT NULL DEFAULT '',
  `img_sm2` varchar(255) NOT NULL DEFAULT '',
  `img_sm3` varchar(255) NOT NULL DEFAULT '',
  `num_views` int(11) NOT NULL DEFAULT '0',
  `num_orders` int(11) NOT NULL DEFAULT '0',
  `price` float(8,2) NOT NULL DEFAULT '0.00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ord` int(4) NOT NULL DEFAULT '0',
  `enabled` int(1) NOT NULL DEFAULT '0',
  `news` int(1) NOT NULL DEFAULT '0',
  `best` int(1) NOT NULL DEFAULT '0',
  `action` int(1) NOT NULL DEFAULT '0',
  `recomended` int(1) NOT NULL DEFAULT '0',
  `words` varchar(255) NOT NULL DEFAULT '',
  `state` int(4) NOT NULL DEFAULT '0',
  `code` varchar(255) NOT NULL DEFAULT '',
  `count_last` int(11) NOT NULL DEFAULT '0',
  `action_for_user` int(11) NOT NULL DEFAULT '0',
  `title_ru` varchar(255) NOT NULL DEFAULT '',
  `meta_title_ru` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords_ru` varchar(255) NOT NULL DEFAULT '',
  `meta_description_ru` varchar(255) NOT NULL DEFAULT '',
  `short_description_ru` mediumtext NOT NULL,
  `description_ru` mediumtext NOT NULL,
  `video_ru` mediumtext NOT NULL,
  `hot` int(1) NOT NULL,
  `cheap` int(1) NOT NULL,
  `nregular` int(1) NOT NULL,
  `tour_start` date NOT NULL,
  `tour_finish` date NOT NULL,
  `duration` varchar(255) NOT NULL,
  `season` varchar(255) NOT NULL,
  `all_places` int(11) NOT NULL,
  `booked_places` int(11) NOT NULL,
  `itinerary` mediumtext NOT NULL,
  `title_en` varchar(255) NOT NULL DEFAULT '',
  `meta_title_en` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords_en` varchar(255) NOT NULL DEFAULT '',
  `meta_description_en` varchar(255) NOT NULL DEFAULT '',
  `short_description_en` mediumtext NOT NULL,
  `description_en` mediumtext NOT NULL,
  `video_en` mediumtext NOT NULL,
  `title_ua` varchar(255) NOT NULL DEFAULT '',
  `meta_title_ua` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords_ua` varchar(255) NOT NULL DEFAULT '',
  `meta_description_ua` varchar(255) NOT NULL DEFAULT '',
  `short_description_ua` text NOT NULL,
  `description_ua` text NOT NULL,
  `video_ua` text NOT NULL,
  `title_az` varchar(255) NOT NULL DEFAULT '',
  `meta_title_az` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords_az` varchar(255) NOT NULL DEFAULT '',
  `meta_description_az` varchar(255) NOT NULL DEFAULT '',
  `short_description_az` text NOT NULL,
  `description_az` text NOT NULL,
  `video_az` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=92 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_catalog` VALUES
(89, 0, 'folder', 'Test', '/', '/Test/', 'empty', '', '', '', '', '', 0, 0, '0.00', '2016-03-26 18:51:18', 0, 1, 0, 0, 0, 0, '', 0, '', 0, 0, 'Test', 'Test', 'Test', 'Test', '', '', '', 0, 0, 0, '0000-00-00', '0000-00-00', '', '', 0, 0, '', 'Test', 'Test', 'Test', 'Test', '', '', '', 'Test', 'Test', 'Test', 'Test', '', '', '', '', '', '', '', '', '', ''),
(90, 0, 'item', '1459011173', '/', '/1459011173/', 'fieldset1', '', '', '', '', '', 0, 0, '0.00', '2016-03-26 18:53:40', 0, 1, 0, 0, 0, 0, '', 0, '', 0, 0, 'asdasdasd123123', '', '', '', '', '', '', 0, 0, 0, '0000-00-00', '0000-00-00', '', '', 0, 0, '', 'asdassdasd123123', '', '', '', '', '', '', 'assdassdasd123123', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(91, 89, 'item', '1459011173', '/1459011173/', '/Test/1459011173/', 'fieldset1', '', '', '', '', '', 0, 0, '11110.00', '2016-03-26 18:54:04', 0, 1, 0, 0, 0, 0, '', 0, '', 0, 0, 'asdasdasd', '', '', '', '', '', '', 0, 0, 0, '0000-00-00', '0000-00-00', '', '', 0, 0, '', 'asdassdasd', '', '', '', '', '', '', 'assdassdasd', '', '', '', '', '', '', '', '', '', '', '', '', '');

DROP TABLE IF EXISTS pm_catalog_baskets;
CREATE TABLE `pm_catalog_baskets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `basket_id` int(11) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `quantity` int(4) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `additional` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_catalog_comments;
CREATE TABLE `pm_catalog_comments` (
  `catalog_comments_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catalog_id` int(11) NOT NULL DEFAULT '0',
  `fio` varchar(255) NOT NULL DEFAULT '',
  `comments` mediumtext,
  `enabled` enum('0','1') NOT NULL DEFAULT '0',
  `dates` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`catalog_comments_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_catalog_currency;
CREATE TABLE `pm_catalog_currency` (
  `currency_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `ratio` float(11,2) NOT NULL DEFAULT '0.00',
  `ord` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`currency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_catalog_currency` VALUES
(1, 'Доллар США', '1.00', 0),
(2, 'Гривна', '8.00', 1);

DROP TABLE IF EXISTS pm_catalog_fieldsets;
CREATE TABLE `pm_catalog_fieldsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_text` varchar(30) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_catalog_fieldsets` VALUES
(4, 'fieldset1', 'Fieldset 1');

DROP TABLE IF EXISTS pm_catalog_fieldsets_data;
CREATE TABLE `pm_catalog_fieldsets_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_text` varchar(30) NOT NULL DEFAULT '',
  `fieldset` varchar(30) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(30) NOT NULL DEFAULT '',
  `options` varchar(255) NOT NULL DEFAULT '',
  `show_list_flag` int(1) NOT NULL DEFAULT '0',
  `show_view_flag` int(1) NOT NULL DEFAULT '0',
  `ord` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_catalog_fieldsets_data` VALUES
(20, 'filed11', 'fieldset1', 'filed1-1', 'string', '', 0, 0, 0),
(21, 'field12', 'fieldset1', 'field1-2', 'number', '', 0, 0, 0),
(22, '1221231231', 'fieldset1', '1223123123', 'multiple', '', 0, 0, 0);

DROP TABLE IF EXISTS pm_catalog_files;
CREATE TABLE `pm_catalog_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `record_id` int(11) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ord` int(4) NOT NULL DEFAULT '0',
  `enabled` int(1) NOT NULL DEFAULT '0',
  `title_ru` varchar(255) NOT NULL DEFAULT '',
  `description_ru` mediumtext NOT NULL,
  `title_en` varchar(255) NOT NULL DEFAULT '',
  `description_en` mediumtext NOT NULL,
  `title_ua` varchar(255) NOT NULL DEFAULT '',
  `description_ua` text NOT NULL,
  `title_az` varchar(255) NOT NULL DEFAULT '',
  `description_az` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_catalog_gallery;
CREATE TABLE `pm_catalog_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `record_id` int(11) NOT NULL DEFAULT '0',
  `meta_title` varchar(255) NOT NULL DEFAULT '',
  `meta_description` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords` varchar(255) NOT NULL DEFAULT '',
  `img` varchar(255) NOT NULL DEFAULT '',
  `img_sm` varchar(255) NOT NULL DEFAULT '',
  `img_sm1` varchar(255) NOT NULL DEFAULT '',
  `img_sm2` varchar(255) NOT NULL DEFAULT '',
  `img_sm3` varchar(255) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ord` int(4) NOT NULL DEFAULT '0',
  `enabled` int(1) NOT NULL DEFAULT '0',
  `title_ru` varchar(255) NOT NULL DEFAULT '',
  `description_ru` mediumtext NOT NULL,
  `title_en` varchar(255) NOT NULL DEFAULT '',
  `description_en` mediumtext NOT NULL,
  `title_ua` varchar(255) NOT NULL DEFAULT '',
  `description_ua` text NOT NULL,
  `title_az` varchar(255) NOT NULL DEFAULT '',
  `description_az` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_catalog_like;
CREATE TABLE `pm_catalog_like` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL DEFAULT '0',
  `to_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_catalog_options;
CREATE TABLE `pm_catalog_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_catalog_options` VALUES
(1, 'img_width', '800'),
(2, 'img_height', '800'),
(3, 'img_sm_width', '200'),
(4, 'img_sm_height', '200'),
(5, 'img_sm1_width', '115'),
(6, 'img_sm1_height', '115'),
(7, 'img_sm2_width', '56'),
(8, 'img_sm2_height', '56'),
(9, 'records_per_page', '1000'),
(10, 'records_per_page_admin', '1000');

DROP TABLE IF EXISTS pm_catalog_orders;
CREATE TABLE `pm_catalog_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `last_name` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `patr` varchar(255) NOT NULL DEFAULT '',
  `country` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `delivery` int(2) NOT NULL DEFAULT '0',
  `type_pay` int(2) NOT NULL DEFAULT '0',
  `webmoney` varchar(50) NOT NULL DEFAULT '',
  `type_face` int(2) NOT NULL DEFAULT '0',
  `action_code` varchar(50) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comments` mediumtext NOT NULL,
  `items` mediumtext NOT NULL,
  `uid` int(11) NOT NULL DEFAULT '0',
  `state` int(4) NOT NULL DEFAULT '0',
  `active` int(1) NOT NULL DEFAULT '0',
  `price` float(11,2) NOT NULL DEFAULT '0.00',
  `price_delivery` float(11,2) NOT NULL DEFAULT '0.00',
  `total_quantity` int(11) NOT NULL DEFAULT '0',
  `currency` int(11) NOT NULL DEFAULT '0',
  `xls_number` int(11) NOT NULL DEFAULT '0',
  `link_file_order` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_catalog_orders_items;
CREATE TABLE `pm_catalog_orders_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `quantity` int(4) NOT NULL DEFAULT '0',
  `price` float(11,2) NOT NULL DEFAULT '0.00',
  `additional` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_catalog_preorders;
CREATE TABLE `pm_catalog_preorders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `record_id` int(11) NOT NULL DEFAULT '0',
  `last_name` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `patr` varchar(255) NOT NULL DEFAULT '',
  `country` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comments` mediumtext NOT NULL,
  `uid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_catalog_selects;
CREATE TABLE `pm_catalog_selects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_text` varchar(30) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `menu_flag` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_catalog_structure;
CREATE TABLE `pm_catalog_structure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `s_id` int(11) NOT NULL DEFAULT '0',
  `toc_id` int(11) NOT NULL DEFAULT '0',
  `record_id` int(11) NOT NULL DEFAULT '0',
  `main_flag` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_catalog_structure` VALUES
(1, 1, 1, 0, 0);

DROP TABLE IF EXISTS pm_catalog_table_fieldset1;
CREATE TABLE `pm_catalog_table_fieldset1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `record_id` int(11) NOT NULL DEFAULT '0',
  `filed11_ru` varchar(255) NOT NULL DEFAULT '',
  `filed11_en` varchar(255) NOT NULL DEFAULT '',
  `filed11_ua` varchar(255) NOT NULL DEFAULT '',
  `field12` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `pm_catalog_table_fieldset1` VALUES
(1, 90, 'ssdasdasd', 'asdasda', 'dasdasdasd', 12313123),
(2, 91, 'ssdasdasd', 'asdasda', 'dasdasdasd', 12313123);

DROP TABLE IF EXISTS pm_common_blocks;
CREATE TABLE `pm_common_blocks` (
  `toc_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(11) NOT NULL DEFAULT '-1',
  `depth` int(11) NOT NULL DEFAULT '-1',
  `template` int(11) unsigned NOT NULL DEFAULT '0',
  `handler` varchar(32) NOT NULL DEFAULT '',
  `order_by` int(11) unsigned NOT NULL DEFAULT '10',
  `limit_to` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`toc_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_content_html;
CREATE TABLE `pm_content_html` (
  `content_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `announce` mediumtext NOT NULL,
  `content` mediumtext NOT NULL,
  `field1` varchar(255) NOT NULL DEFAULT '',
  `field2` varchar(255) NOT NULL DEFAULT '',
  `field3` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`),
  FULLTEXT KEY `content` (`content`)
) ENGINE=MyISAM AUTO_INCREMENT=9 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_content_html` VALUES
(1, '', '', '', '', '', ''),
(2, 'About CyBuy project', '', '<p>Симулякр нивелирует ритм. Наш современник стал особенно чутко относиться к слову, однако заимствование неумеренно аллитерирует реформаторский пафос. Жирмунский, однако, настаивал, что катахреза отражает диалогический контекст. Субъективное восприятие прекрасно аллитерирует культурный дольник, где автор является полновластным хозяином своих персонажей, а они - его марионетками. Эстетическое воздействие косвенно.</p>\r\n\r\n<p>Ю.Лотман, не дав ответа, тут же запутывается в проблеме превращения не-текста в текст, поэтому нет смысла утверждать, что впечатление потенциально. Показательный пример &ndash; дактиль прекрасно вызывает конкретный акцент. Голос персонажа традиционен. Лирика отталкивает глубокий ямб. Правило альтернанса, как бы это ни казалось парадоксальным, просветляет символ.</p>\r\n\r\n<p>Аллюзия редуцирует лирический холодный цинизм. Метонимия, согласно традиционным представлениям, приводит механизм сочленений. Лирика, без использования формальных признаков поэзии, притягивает стиль. Стих неравномерен. С семантической точки зрения, олицетворение вразнобой редуцирует дискурс.</p>', '', '', ''),
(3, 'Privacy Policy', '', '<p>Несомненно, &nbsp;легитимность власти категорически вызывает системный либерализм. Конфедерация практически верифицирует христианско-демократический национализм, отмечает Б.Рассел. Международная политика&nbsp;<br />\r\nоднозначно сохраняет классический кризис легитимности. Глобализация, как бы это ни казалось парадоксальным, приводит классический гуманизм, хотя на первый взгляд, российские власти тут ни при чем.</p>\r\n\r\n<p>Очевидно, что &nbsp;идеология предсказуема. Политическое манипулирование теоретически интегрирует либерализм. Рационально-критическая парадигма иллюстрирует классический континентально-европейский тип политической культуры. Политическое учение Платона вызывает марксизм.</p>\r\n\r\n<p>Еще Шпенглер в &quot;Закате Европы&quot; писал, что капиталистическое мировое общество важно иллюстрирует прагматический коллапс Советского Союза. Мажоритарная избирательная система вызывает референдум. Политический процесс в современной России, однако, неоднозначен. Капиталистическое мировое общество взаимно. Политическая психология, однако, теоретически доказывает прагматический субъект политического процесса. Социализм вызывает авторитаризм.</p>', '', '', ''),
(4, '', '', '', '', '', ''),
(5, '', '', '', '', '', ''),
(6, '', '', '', '', '', ''),
(7, '', '', '', '', '', ''),
(8, 'About CyBuy project', '', '<div>\r\n<p>Несомненно, легитимность власти категорически вызывает системный либерализм. Конфедерация практически верифицирует христианско-демократический национализм, отмечает Б.Рассел. Международная политика однозначно сохраняет классический кризис легитимности. Глобализация, как бы это ни казалось парадоксальным, приводит классический гуманизм, хотя на первый взгляд, российские власти тут ни при чем.</p>\r\n\r\n<p>Очевидно, что идеология предсказуема. Политическое манипулирование теоретически интегрирует либерализм. Рационально-критическая парадигма иллюстрирует классический континентально-европейский тип политической культуры. Политическое учение Платона вызывает марксизм.</p>\r\n\r\n<p>Еще Шпенглер в &quot;Закате Европы&quot; писал, что капиталистическое мировое общество важно иллюстрирует прагматический коллапс Советского Союза. Мажоритарная избирательная система вызывает референдум. Политический процесс в современной России, однако, неоднозначен. Капиталистическое мировое общество взаимно. Политическая психология, однако, теоретически доказывает прагматический субъект политического процесса. Социализм вызывает авторитаризм.</p>\r\n</div>', '', '', '');

DROP TABLE IF EXISTS pm_feedback;
CREATE TABLE `pm_feedback` (
  `feedback_id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `s_id` int(5) unsigned NOT NULL DEFAULT '0',
  `toc_id` int(5) unsigned NOT NULL DEFAULT '0',
  `enabled` int(1) unsigned NOT NULL DEFAULT '0',
  `sort_order` int(2) unsigned NOT NULL DEFAULT '0',
  `mail` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`feedback_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_feedback` VALUES
(1, 246, 16, 1, 0, 'ibolosig@gmail.com');

DROP TABLE IF EXISTS pm_gallery;
CREATE TABLE `pm_gallery` (
  `gallery_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `type` int(1) NOT NULL DEFAULT '0',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `relative_url` varchar(255) NOT NULL DEFAULT '',
  `title_ru` varchar(255) NOT NULL DEFAULT '',
  `title_en` varchar(255) NOT NULL DEFAULT '',
  `title_ua` varchar(255) NOT NULL DEFAULT '',
  `meta_title_ru` varchar(255) NOT NULL DEFAULT '',
  `meta_title_en` varchar(255) NOT NULL DEFAULT '',
  `meta_title_ua` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords_ru` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords_en` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords_ua` varchar(255) NOT NULL DEFAULT '',
  `meta_description_ru` varchar(255) NOT NULL DEFAULT '',
  `meta_description_en` varchar(255) NOT NULL DEFAULT '',
  `meta_description_ua` varchar(255) NOT NULL DEFAULT '',
  `descr_ru` mediumtext NOT NULL,
  `descr_en` mediumtext NOT NULL,
  `descr_ua` mediumtext NOT NULL,
  `content_ru` mediumtext NOT NULL,
  `content_en` mediumtext NOT NULL,
  `content_ua` mediumtext NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT '',
  `img_sh` varchar(255) NOT NULL DEFAULT '',
  `img_sm` varchar(255) NOT NULL DEFAULT '',
  `img_sm1` varchar(255) NOT NULL DEFAULT '',
  `author` varchar(255) NOT NULL DEFAULT '',
  `source` varchar(255) NOT NULL DEFAULT '',
  `source_url` varchar(255) NOT NULL DEFAULT '',
  `ord` int(11) NOT NULL DEFAULT '0',
  `enabled` int(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visited` int(10) unsigned NOT NULL DEFAULT '0',
  `words` varchar(255) NOT NULL,
  PRIMARY KEY (`gallery_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1946 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_gallery_comments;
CREATE TABLE `pm_gallery_comments` (
  `comment_id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Идентификатор родительского комментария. Если 0 - корневой комментарий.',
  `user_id` varchar(255) NOT NULL DEFAULT '',
  `gallery_id` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment` mediumtext NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_gallery_options;
CREATE TABLE `pm_gallery_options` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `value` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_gallery_structure;
CREATE TABLE `pm_gallery_structure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `s_id` int(11) NOT NULL DEFAULT '0',
  `toc_id` int(11) NOT NULL DEFAULT '0',
  `record_id` int(11) NOT NULL DEFAULT '0',
  `open_this` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_languages;
CREATE TABLE `pm_languages` (
  `language_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL DEFAULT '',
  `short_title` varchar(24) NOT NULL DEFAULT '',
  `alias` varchar(64) NOT NULL DEFAULT '',
  `enabled` int(1) unsigned NOT NULL DEFAULT '0',
  `ord` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_languages` VALUES
(1, 'Russian', 'ru', 'ru', 1, 1),
(4, 'Ukrainian', 'ua', 'ua', 4294967295, 3),
(5, 'English', 'en', 'en', 4294967294, 2);

DROP TABLE IF EXISTS pm_news;
CREATE TABLE `pm_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original_id` int(11) NOT NULL,
  `language` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `enabled` int(1) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `descr` mediumtext,
  `content` mediumtext,
  `img_orig` varchar(255) NOT NULL DEFAULT '',
  `img` varchar(255) NOT NULL DEFAULT '',
  `post_date` datetime NOT NULL,
  `dates` date NOT NULL DEFAULT '0000-00-00',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceName` varchar(255) NOT NULL DEFAULT '',
  `sourceUrl` varchar(255) NOT NULL DEFAULT '',
  `rubrics` varchar(255) NOT NULL DEFAULT '',
  `tags` varchar(255) NOT NULL DEFAULT '',
  `auto_start` int(1) NOT NULL DEFAULT '0',
  `dates_start` date NOT NULL DEFAULT '0000-00-00',
  `dates_end` date NOT NULL DEFAULT '0000-00-00',
  `meta_title` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords` varchar(255) NOT NULL DEFAULT '',
  `meta_description` varchar(255) NOT NULL DEFAULT '',
  `words` varchar(255) NOT NULL,
  `rubrics_list` varchar(255) NOT NULL,
  `img_sm` varchar(255) NOT NULL DEFAULT '',
  `img_sm1` varchar(255) NOT NULL DEFAULT '',
  `img_sm2` varchar(255) NOT NULL DEFAULT '',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_news` VALUES
(1, 0, '', 'topic-1', 1, 'Topic 1', '<p>Topic 1 announcement</p>', '<p>Topic 1 content</p>', '', '', '0000-00-00 00:00:00', '2016-05-24', 'Author', 'Source', 'Source link', '|74|', '', 0, '2016-05-24', '2016-06-24', 'Topic 1 title', '', 'Topic 1 description', '', '', '', '', '', 1, NULL),
(2, 1, 'ru', '', 0, 'Topic 1', '<p>Topic 1 announcement</p>', '<p>Topic 1 content</p>', '', '', '0000-00-00 00:00:00', '0000-00-00', '', '', '', '', '', 0, '0000-00-00', '0000-00-00', 'Topic 1 title', '', 'Topic 1 description', '', '', '', '', '', 0, NULL),
(3, 1, 'en', '', 0, '', NULL, NULL, '', '', '0000-00-00 00:00:00', '0000-00-00', '', '', '', '', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', '', 0, NULL),
(4, 1, 'ua', '', 0, '', NULL, NULL, '', '', '0000-00-00 00:00:00', '0000-00-00', '', '', '', '', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', '', 0, NULL),
(5, 0, '', 'topic-2', 1, 'Topic 2', '<p>Topic-2 announcement</p>', '<p>Topic-2 description</p>', '', '', '0000-00-00 00:00:00', '2016-05-24', '', '', '', '|74|', '', 0, '2016-05-24', '2016-06-24', 'topic-2 title', '', 'topic-2 description', '', '', '', '', '', 1, NULL);

DROP TABLE IF EXISTS pm_news_calendar;
CREATE TABLE `pm_news_calendar` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `s_id` int(11) unsigned NOT NULL DEFAULT '0',
  `toc_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `block_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_news_comments;
CREATE TABLE `pm_news_comments` (
  `comment_id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL DEFAULT '',
  `news_id` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment` mediumtext,
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_news_gallery;
CREATE TABLE `pm_news_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `news_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `descr` mediumtext,
  `meta_title` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords` varchar(255) NOT NULL DEFAULT '',
  `meta_description` varchar(255) NOT NULL DEFAULT '',
  `img_orig` varchar(255) NOT NULL DEFAULT '',
  `img` varchar(255) NOT NULL DEFAULT '',
  `img_sm` varchar(255) NOT NULL DEFAULT '',
  `img_sm1` varchar(255) NOT NULL DEFAULT '',
  `enabled` int(1) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `ord` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `img_sm2` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_news_options;
CREATE TABLE `pm_news_options` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `value` int(11) unsigned NOT NULL DEFAULT '0',
  `value2` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `groups` int(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_news_options` VALUES
(1, 'defaultWidth', 800, '800.0000', 1),
(2, 'defaultHeight', 800, '800.0000', 1),
(3, 'defaultWidthSm', 270, '270.0000', 2),
(4, 'defaultHeightSm', 183, '183.0000', 2),
(5, 'defaultWidthSm1', 137, '137.0000', 3),
(6, 'defaultHeightSm1', 92, '92.0000', 3),
(7, 'defaultWidthSm2', 126, '126.0000', 4),
(8, 'defaultHeightSm2', 126, '126.0000', 4);

DROP TABLE IF EXISTS pm_news_rubrics;
CREATE TABLE `pm_news_rubrics` (
  `rubric_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_menu` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `meta_title` varchar(255) NOT NULL DEFAULT '',
  `meta_description` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`rubric_id`)
) ENGINE=MyISAM AUTO_INCREMENT=75 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_news_rubrics` VALUES
(74, 'CyBuy news', 'News', '', '', '', '', 'news');

DROP TABLE IF EXISTS pm_news_structure;
CREATE TABLE `pm_news_structure` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `s_id` int(11) unsigned NOT NULL DEFAULT '0',
  `toc_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `sorttype` varchar(255) NOT NULL DEFAULT 'id',
  `lim` int(11) unsigned NOT NULL DEFAULT '5',
  `show_navi` int(1) NOT NULL DEFAULT '0',
  `block_id` int(11) NOT NULL DEFAULT '0',
  `rubrics` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_news_structure` VALUES
(1, 244, 17, 'CyBuy News', 'dates', 10, 0, 1, '|74|');

DROP TABLE IF EXISTS pm_shop_catregories;
CREATE TABLE `pm_shop_catregories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parent` int(10) unsigned NOT NULL,
  `alias` varchar(255) NOT NULL,
  `id_fieldset` int(10) unsigned NOT NULL,
  `is_active` enum('n','y') NOT NULL DEFAULT 'n',
  `name_ua` varchar(255) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `description_ua` text NOT NULL,
  `description_en` text NOT NULL,
  `description_ru` text NOT NULL,
  `title_ua` varchar(255) NOT NULL,
  `title_en` varchar(255) NOT NULL,
  `title_ru` varchar(255) NOT NULL,
  `meta_keywords_ua` text NOT NULL,
  `meta_keywords_en` text NOT NULL,
  `meta_keywords_ru` text NOT NULL,
  `meta_desc_ua` text NOT NULL,
  `meta_desc_en` text NOT NULL,
  `meta_desc_ru` text NOT NULL,
  `datetime_created` datetime NOT NULL,
  `datetime_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='Shop categories table';

INSERT INTO `pm_shop_catregories` VALUES
(1, 0, 'test', 0, 'y', 'qweqwe', 'asdasd', 'zxczxc', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL),
(2, 0, '', 0, 'y', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL),
(3, 1, '', 0, 'y', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL),
(4, 3, 'test4', 4, 'y', 'test', 'test', 'test', '', '', '', 'test', 'test', 'test', '', '', '', '', '', '', '0000-00-00 00:00:00', '2016-04-15 18:16:39'),
(5, 1, '', 0, 'y', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL),
(6, 0, '', 0, 'n', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2016-04-11 18:22:05', NULL),
(7, 1, 'sddsasdaddsa', 0, 'n', 'sdasdasdaasd', 'sdsdsdasda', 'sdasdada@\"asda\'', '', '', '', 'qweqweqweq', 'qweqweqweq', 'qweqweqwe', 'qweqweq', '', '', 'xzzxcxczxczxczzxczx', '', '', '2016-04-12 11:48:52', '2016-04-12 12:08:16'),
(8, 7, 'sddsasdaddsa2', 0, 'y', 'sdasdasdaasd2', 'sdsdsdasda2', 'sdasdada@\"asda\'2', '', '', '', '!!!!!#', '!!2', '!!!!!', '', '', '', '', '', '', '2016-04-12 11:53:26', '2016-04-12 12:07:04');

DROP TABLE IF EXISTS pm_shop_fieldset;
CREATE TABLE `pm_shop_fieldset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `data` text NOT NULL COMMENT 'JSONed additional fields config',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_shop_fieldset` VALUES
(2, '12weqdas22', '[{\"id\":\"0\",\"names\":{\"ru\":\"WSDAX22\",\"en\":\"QwdsaCXZ22\",\"ua\":\"dasCxz22\"},\"type\":\"string\",\"required\":true,\"enabled\":false},{\"id\":\"1\",\"names\":{\"ru\":\"weafsdx22\",\"en\":\"weafsdxcz22\",\"ua\":\"weafsvdzx22\"},\"type\":\"date\",\"required\":false,\"enabled\":true}]'),
(3, 'dszcvzxv', '[{\"id\":\"0\",\"names\":{\"ru\":\"qwasCX\",\"en\":\"XZCZX\",\"ua\":\"cZXCZXc\"},\"type\":\"int\",\"required\":\"true\",\"enabled\":\"true\"},{\"id\":\"1\",\"names\":{\"ru\":\"ftujghmghlukbj,\",\"en\":\"vhl9ujjlbm,,liu7hlbijk\",\"ua\":\"giliub,hj,mgluib,hj\"},\"type\":\"float\",\"required\":\"true\",\"enabled\":\"true\"}]'),
(4, 'Test fieldset', '[{\"id\":\"0\",\"names\":{\"ru\":\"Field multiselect ru\",\"en\":\"Field multiselect en\",\"ua\":\"Field multiselect ua\"},\"type\":\"multiselect\",\"options\":[{\"id\":\"134\",\"names\":{\"ru\":\"sdasdasda\",\"en\":\"sdasda\",\"ua\":\"sda\"}},{\"id\":\"2\",\"names\":{\"ru\":\"weqweqweq\",\"en\":\"weq22\",\"ua\":\"weqweq\"}}],\"required\":true,\"enabled\":true},{\"id\":\"1\",\"names\":{\"ru\":\"Field string ru\",\"en\":\"Field string en\",\"ua\":\"Field string ua\"},\"type\":\"string\",\"required\":true,\"enabled\":true},{\"id\":\"2\",\"names\":{\"ru\":\"Field int ru\",\"en\":\"Field int en\",\"ua\":\"Field int ua\"},\"type\":\"int\",\"required\":true,\"enabled\":true},{\"id\":\"3\",\"names\":{\"ru\":\"Field float ru\",\"en\":\"Field float en\",\"ua\":\"Field float ua\"},\"type\":\"float\",\"required\":true,\"enabled\":true},{\"id\":\"4\",\"names\":{\"ru\":\"Field select ru\",\"en\":\"Field select en\",\"ua\":\"Field select ua\"},\"type\":\"select\",\"options\":[{\"id\":\"1\",\"names\":{\"ru\":\"q\",\"en\":\"qq\",\"ua\":\"qqq\"}},{\"id\":\"2\",\"names\":{\"ru\":\"w\",\"en\":\"ww\",\"ua\":\"www\"}},{\"id\":\"3\",\"names\":{\"ru\":\"e\",\"en\":\"ee\",\"ua\":\"eee\"}},{\"id\":\"4\",\"names\":{\"ru\":\"r\",\"en\":\"rr\",\"ua\":\"rrr\"}}],\"required\":true,\"enabled\":true}]');

DROP TABLE IF EXISTS pm_shop_items;
CREATE TABLE `pm_shop_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_category` int(10) unsigned NOT NULL,
  `id_user` int(10) unsigned NOT NULL,
  `is_active` enum('n','y') NOT NULL DEFAULT 'n',
  `is_banned` enum('n','y') NOT NULL DEFAULT 'n',
  `name_ua` varchar(255) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `desc_ua` text NOT NULL,
  `desc_en` text NOT NULL,
  `desc_ru` text NOT NULL,
  `media` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `fields` text NOT NULL,
  `times_ordered` int(10) unsigned NOT NULL,
  `times_bought` int(10) unsigned NOT NULL,
  `times_viewed` int(10) unsigned NOT NULL,
  `datetime_created` datetime NOT NULL,
  `datetime_modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_category` (`id_category`),
  KEY `id_user` (`id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=9 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_shop_items` VALUES
(2, 4, 1, 'y', 'n', 'TEST name ua', 'TEST name en', 'TEST name ru 123', 'description ua', 'description en NOPE', 'description ru\nLOOOONG ONE\nEXTRA', '[{\"id\":0,\"type\":\"image\",\"url\":\"\\/content\\/shop\\/items\\/2-0-1461254457.jpg\",\"originalname\":\"3024d1_3839036.jpg\",\"name\":\"2-0-1461254457.jpg\",\"original\":\"2-0-1461254457-original.jpg\",\"width\":500,\"height\":389,\"originalwidth\":2500,\"originalheight\":1945,\"active\":true,\"order\":10,\"originalurl\":\"\\/content\\/shop\\/items\\/2-0-1461254457-original.jpg\"},{\"id\":2,\"type\":\"image\",\"url\":\"\\/content\\/shop\\/items\\/2-2-1461254457.jpg\",\"originalname\":\"_.jpg\",\"name\":\"2-2-1461254457.jpg\",\"original\":\"2-2-1461254457-original.jpg\",\"width\":336,\"height\":500,\"originalwidth\":640,\"originalheight\":953,\"active\":true,\"order\":20,\"originalurl\":\"\\/content\\/shop\\/items\\/2-2-1461254457-original.jpg\"},{\"id\":4,\"type\":\"image\",\"url\":\"\\/content\\/shop\\/items\\/2-4-1461258543.jpg\",\"originalname\":\"0d650c_4476999.jpg\",\"name\":\"2-4-1461258543.jpg\",\"original\":\"2-4-1461258543-original.jpg\",\"width\":500,\"height\":313,\"originalwidth\":1440,\"originalheight\":900,\"active\":true,\"order\":21,\"originalurl\":\"\\/content\\/shop\\/items\\/2-4-1461258543-original.jpg\"},{\"id\":3,\"type\":\"image\",\"url\":\"\\/content\\/shop\\/items\\/2-3-1461257513.jpg\",\"originalname\":\"ScF4vjpTHKU.jpg\",\"name\":\"2-3-1461257513.jpg\",\"original\":\"2-3-1461257513-original.jpg\",\"width\":500,\"height\":297,\"originalwidth\":1024,\"originalheight\":609,\"active\":true,\"order\":30,\"originalurl\":\"\\/content\\/shop\\/items\\/2-3-1461257513-original.jpg\"},{\"id\":1,\"type\":\"video\",\"url\":\"https:\\/\\/www.youtube.com\\/watch?v=Us_V6KX7UqU\",\"active\":false,\"order\":40},{\"id\":5,\"type\":\"image\",\"url\":\"\\/content\\/shop\\/items\\/2-5-1461261038.jpg\",\"originalurl\":\"\\/content\\/shop\\/items\\/2-5-1461261038-original.jpg\",\"originalname\":\"4EYsgtyYKR0.jpg\",\"name\":\"2-5-1461261038.jpg\",\"original\":\"2-5-1461261038-original.jpg\",\"mininame\":\"2-5-1461261038-mini.jpg\",\"miniurl\":\"\\/content\\/shop\\/items\\/2-5-1461261038-mini.jpg\",\"width\":500,\"height\":232,\"originalwidth\":604,\"originalheight\":280,\"active\":true,\"order\":41}]', '123.12', '[[\"2\"],\"Field string 123\",\"123\",\"123.666\",\"1\"]', 0, 0, 0, '2016-04-06 07:37:18', '2016-04-23 06:31:27'),
(3, 4, 1, 'y', 'n', 'test2', 'test2', 'test2', 'test2', 'test2', 'test2', '', '11.60', '[[\"134\",\"2\"],\"AS\",\"123123\",\"1.1567\",\"4\"]', 0, 0, 0, '2016-04-19 21:10:50', '2016-04-20 03:12:04'),
(4, 1, 1, 'y', 'n', '123', '123', '1223', '123', '123', '123', '[{\"id\":1,\"type\":\"image\",\"url\":\"\\/content\\/shop\\/items\\/4-1-1461261399.jpg\",\"originalurl\":\"\\/content\\/shop\\/items\\/4-1-1461261399-original.jpg\",\"originalname\":\"!VCard Tkachenko Andrew.gif\",\"name\":\"4-1-1461261399.jpg\",\"original\":\"4-1-1461261399-original.jpg\",\"mininame\":\"4-1-1461261399-mini.jpg\",\"miniurl\":\"\\/content\\/shop\\/items\\/4-1-1461261399-mini.jpg\",\"width\":500,\"height\":500,\"originalwidth\":584,\"originalheight\":584,\"active\":true,\"order\":1}]', '123.00', '[]', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 1, 1, 'y', 'n', '12231223', '123123', '123123', '123123', '123123', '12231223', '[{\"id\":1,\"type\":\"image\",\"url\":\"\\/content\\/shop\\/items\\/5-1-1461261494.jpg\",\"originalurl\":\"\\/content\\/shop\\/items\\/5-1-1461261494-original.jpg\",\"originalname\":\"\\u0421\\u040f\\u0420\\u0454\\u0421\\u0453\\u0421\\u201a\\u0420\\u0451\\u0421\\u040f-\\u0420\\u0491\\u0420\\u00bb\\u0421\\u040f-\\u0421\\u201a\\u0420\\u00b5\\u0421\\u2026-\\u0420\\u0454\\u0420\\u0455\\u0420\\u0456\\u0420\\u0455-\\u0421\\u201a\\u0420\\u00b0\\u0420\\u0458-\\u0420\\u0405\\u0420\\u00b5\\u0421\\u201a-\\u0420\\u00b1\\u0420\\u00b5\\u0420\\u00b7\\u0421\\u2039\\u0421\\u0403\\u0421\\u2026\\u0420\\u0455\\u0420\\u0491\\u0420\\u0405\\u0420\\u0455\\u0421\\u0403\\u0421\\u201a\\u0421\\u040a-\\u0420\\u0457\\u0420\\u0455\\u0421\\u0403\\u0421\\u201a-\\u0421\\u0402\\u0420\\u0455\\u0420\\u0454-519006.jpeg\",\"name\":\"5-1-1461261494.jpg\",\"original\":\"5-1-1461261494-original.jpg\",\"mininame\":\"5-1-1461261494-mini.jpg\",\"miniurl\":\"\\/content\\/shop\\/items\\/5-1-1461261494-mini.jpg\",\"width\":500,\"height\":414,\"originalwidth\":500,\"originalheight\":414,\"active\":true,\"order\":1}]', '1212.00', '[]', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 1, 1, 'y', 'n', '12231223', '123123', '123123', '123123', '123123', '12231223', '[{\"id\":1,\"type\":\"image\",\"url\":\"\\/content\\/shop\\/items\\/6-1-1461261536.jpg\",\"originalurl\":\"\\/content\\/shop\\/items\\/6-1-1461261536-original.jpg\",\"originalname\":\"\\u0421\\u040f\\u0420\\u0454\\u0421\\u0453\\u0421\\u201a\\u0420\\u0451\\u0421\\u040f-\\u0420\\u0491\\u0420\\u00bb\\u0421\\u040f-\\u0421\\u201a\\u0420\\u00b5\\u0421\\u2026-\\u0420\\u0454\\u0420\\u0455\\u0420\\u0456\\u0420\\u0455-\\u0421\\u201a\\u0420\\u00b0\\u0420\\u0458-\\u0420\\u0405\\u0420\\u00b5\\u0421\\u201a-\\u0420\\u00b1\\u0420\\u00b5\\u0420\\u00b7\\u0421\\u2039\\u0421\\u0403\\u0421\\u2026\\u0420\\u0455\\u0420\\u0491\\u0420\\u0405\\u0420\\u0455\\u0421\\u0403\\u0421\\u201a\\u0421\\u040a-\\u0420\\u0457\\u0420\\u0455\\u0421\\u0403\\u0421\\u201a-\\u0421\\u0402\\u0420\\u0455\\u0420\\u0454-519006.jpeg\",\"name\":\"6-1-1461261536.jpg\",\"original\":\"6-1-1461261536-original.jpg\",\"mininame\":\"6-1-1461261536-mini.jpg\",\"miniurl\":\"\\/content\\/shop\\/items\\/6-1-1461261536-mini.jpg\",\"width\":500,\"height\":414,\"originalwidth\":500,\"originalheight\":414,\"active\":true,\"order\":1}]', '1212.00', '[]', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 4, 1, 'y', 'n', 'test 2', 'test 2', 'test 2', 'test 2', 'test 2', 'test 2', '[{\"id\":1,\"type\":\"image\",\"url\":\"\\/content\\/shop\\/items\\/7-1-1461672881.jpg\",\"originalurl\":\"\\/content\\/shop\\/items\\/7-1-1461672881-original.jpg\",\"originalname\":\"3-70AoLkwv4.jpg\",\"name\":\"7-1-1461672881.jpg\",\"original\":\"7-1-1461672881-original.jpg\",\"mininame\":\"7-1-1461672881-mini.jpg\",\"miniurl\":\"\\/content\\/shop\\/items\\/7-1-1461672881-mini.jpg\",\"width\":500,\"height\":411,\"originalwidth\":957,\"originalheight\":786,\"active\":true,\"order\":1}]', '11.00', '[[\"2\"],\"aaa\",\"678\",\"55\",\"3\"]', 0, 0, 0, '2016-04-26 12:14:41', '0000-00-00 00:00:00'),
(8, 4, 1, 'y', 'n', 'test 3', 'test 3', 'test 3', 'test 3', 'test 3', 'test 3', '[{\"id\":1,\"type\":\"image\",\"url\":\"\\/content\\/shop\\/items\\/8-1-1461672950.jpg\",\"originalurl\":\"\\/content\\/shop\\/items\\/8-1-1461672950-original.jpg\",\"originalname\":\"_350780.jpeg\",\"name\":\"8-1-1461672950.jpg\",\"original\":\"8-1-1461672950-original.jpg\",\"mininame\":\"8-1-1461672950-mini.jpg\",\"miniurl\":\"\\/content\\/shop\\/items\\/8-1-1461672950-mini.jpg\",\"width\":450,\"height\":500,\"originalwidth\":543,\"originalheight\":604,\"active\":true,\"order\":1},{\"id\":2,\"type\":\"image\",\"url\":\"\\/content\\/shop\\/items\\/8-2-1461672950.jpg\",\"originalurl\":\"\\/content\\/shop\\/items\\/8-2-1461672950-original.jpg\",\"originalname\":\"2Wt3AB_Gmu4.jpg\",\"name\":\"8-2-1461672950.jpg\",\"original\":\"8-2-1461672950-original.jpg\",\"mininame\":\"8-2-1461672950-mini.jpg\",\"miniurl\":\"\\/content\\/shop\\/items\\/8-2-1461672950-mini.jpg\",\"width\":386,\"height\":500,\"originalwidth\":790,\"originalheight\":1024,\"active\":true,\"order\":2}]', '999.00', '[[\"134\"],\"sdcx\",\"64\",\"389\",\"4\"]', 0, 0, 0, '2016-04-26 12:15:50', '0000-00-00 00:00:00');

DROP TABLE IF EXISTS pm_shop_orders;
CREATE TABLE `pm_shop_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(11) unsigned NOT NULL,
  `hash` char(32) NOT NULL,
  `datetime_modified` datetime NOT NULL,
  `status` enum('new','pending','done') NOT NULL DEFAULT 'new',
  `total_price` decimal(10,2) NOT NULL,
  `shipping` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_shop_orders` VALUES
(1, 0, '', '2016-05-02 13:36:01', 'new', '123.00', ''),
(2, 0, '', '2016-05-02 13:37:02', 'new', '1230.00', ''),
(3, 0, 'ffcbb888f6de6c5351551a76422736a0', '2016-05-02 13:37:53', 'new', '2460.00', ''),
(4, 1, '', '2016-05-02 13:56:44', 'new', '1241.60', '');

DROP TABLE IF EXISTS pm_shop_orders_items;
CREATE TABLE `pm_shop_orders_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_order` int(10) unsigned NOT NULL,
  `id_item` int(10) unsigned NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_order` (`id_order`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_shop_orders_items` VALUES
(1, 0, 4, '123.00', 10),
(2, 1, 4, '123.00', 10),
(3, 2, 4, '123.00', 10),
(4, 3, 4, '123.00', 20),
(5, 4, 4, '123.00', 10),
(6, 4, 3, '11.60', 1);

DROP TABLE IF EXISTS pm_structure;
CREATE TABLE `pm_structure` (
  `s_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_menu` varchar(255) NOT NULL DEFAULT '',
  `title_page` varchar(255) NOT NULL DEFAULT '',
  `title_map` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords` mediumtext NOT NULL,
  `meta_description` mediumtext NOT NULL,
  `level` int(11) unsigned NOT NULL DEFAULT '0',
  `alias` varchar(64) NOT NULL DEFAULT '',
  `relative_url` varchar(255) NOT NULL DEFAULT '',
  `parent` int(11) unsigned NOT NULL DEFAULT '0',
  `template_id` int(11) unsigned NOT NULL DEFAULT '0',
  `type` int(1) unsigned NOT NULL DEFAULT '0',
  `enabled` int(1) unsigned NOT NULL DEFAULT '0',
  `restricted` int(1) unsigned NOT NULL DEFAULT '0',
  `access_level` int(11) NOT NULL DEFAULT '0',
  `show_search` int(1) unsigned NOT NULL DEFAULT '1',
  `show_map` int(1) unsigned NOT NULL DEFAULT '1',
  `show_menu_top` int(1) unsigned NOT NULL DEFAULT '1',
  `second_menu` int(11) NOT NULL DEFAULT '0',
  `show_menu_side` int(1) unsigned NOT NULL DEFAULT '1',
  `show_menu_bottom` int(1) unsigned NOT NULL DEFAULT '1',
  `redirect_url` varchar(255) NOT NULL DEFAULT '',
  `cache_id` int(11) unsigned NOT NULL DEFAULT '0',
  `cache_lifetime` int(11) unsigned NOT NULL DEFAULT '0',
  `creation_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modification_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ord` int(11) unsigned NOT NULL DEFAULT '0',
  `tags` varchar(255) NOT NULL DEFAULT '',
  `count_visit` int(11) unsigned NOT NULL DEFAULT '0',
  `show_menu_top2` int(1) unsigned NOT NULL DEFAULT '1',
  `words` varchar(255) NOT NULL,
  `left_key` int(12) NOT NULL,
  `right_key` int(12) NOT NULL,
  `group_id` smallint(255) NOT NULL DEFAULT '0',
  `static` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`s_id`)
) ENGINE=MyISAM AUTO_INCREMENT=247 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_structure` VALUES
(1, 'Главная страница', '', '', '', 'Главная страница', '', '', 1, 'ru', 'ru/', 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, '', 731, 0, '2010-10-04 07:01:23', '2016-05-26 18:05:24', 1, 1, 'Проект ФотоТур', 515, 0, '|14|22|6|81|80|27|25|7|9|21|', 0, 0, 1, 0),
(222, 'Ukrainian', '', '', '', 'Ukrainian', '', '', 1, 'ua', 'ua/', 0, 26, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, '', 21, 0, '2015-03-20 15:30:30', '2015-09-14 15:39:30', 4, 3, '', 0, 0, '', 0, 0, 1, 0),
(223, 'English', '', '', '', 'Mjolnir design studio based in Kyiv', '', 'Web-design, complex web implementations, identity and much more.', 1, 'en', 'en/', 0, 26, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, '', 12, 0, '2015-03-20 15:30:50', '2016-01-06 12:18:40', 5, 2, '', 0, 0, '', 0, 0, 1, 0),
(226, 'News', 'News', '', '', 'What\'s happening here at Mjolnir design studio.', '', '', 2, 'wjo', 'en/wjo/', 223, 26, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, '', 4, 0, '2015-09-01 12:26:07', '2015-09-01 12:43:26', 5, 1, '', 0, 1, '', 0, 0, 1, 0),
(227, 'Вакансії', '', '', '', 'Вакансії у Mjolnir', '', '', 2, 'job', 'ua/job/', 222, 26, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, '', 5, 0, '2015-09-01 15:53:35', '2015-09-01 15:54:54', 4, 1, '', 0, 1, '', 0, 0, 1, 0),
(228, 'Вйо', '', '', '', 'Вйо — дизайномайстерня Mjolnir', '', '', 2, 'wjo', 'ua/wjo/', 222, 26, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, '', 8, 0, '2015-09-01 15:55:18', '2015-09-14 19:24:52', 4, 2, '', 0, 1, '', 0, 0, 1, 0),
(229, 'Наші роботи', '', '', '', 'Портфоліо студії Mjolnir', '', '', 2, 'we-do', 'ua/we-do/', 222, 26, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, '', 4, 0, '2015-09-01 16:17:30', '2015-09-01 16:19:13', 4, 3, '', 0, 1, '', 0, 0, 1, 0),
(232, 'Portfolio', '', '', '', 'Mjolnir portfolio', '', '', 2, 'we-do', 'en/we-do/', 223, 26, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, '', 3, 0, '2015-09-03 15:45:11', '2015-09-03 15:46:04', 5, 2, '', 0, 1, '', 0, 0, 1, 0),
(240, 'Something', '', '', '', '', '', '', 2, 'something', 'ru/something/', 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, '', 16, 0, '2016-04-21 15:07:59', '2016-04-26 15:48:04', 1, 1, '', 0, 1, '', 0, 0, 0, 0),
(241, 'About us', '', '', '', '', '', '', 2, 'about-us', 'ru/about-us/', 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, '', 3, 0, '2016-05-24 19:56:45', '2016-05-24 20:04:35', 1, 2, '', 0, 1, '', 0, 0, 0, 0),
(242, 'Privacy Policy', '', '', '', '', '', '', 2, 'privacy-policy', 'ru/privacy-policy/', 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, '', 3, 0, '2016-05-24 19:57:05', '2016-05-24 20:10:53', 1, 3, '', 0, 1, '', 0, 0, 0, 0),
(244, 'News', '', '', '', '', '', '', 2, 'news', 'ru/news/', 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, '', 2, 0, '2016-05-24 20:00:05', '2016-05-24 20:11:22', 1, 4, '', 0, 1, '', 0, 0, 0, 0),
(245, 'Register', '', '', '', '', '', '', 2, 'register', 'ru/register/', 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, '', 2, 0, '2016-05-24 20:01:16', '2016-05-24 20:07:24', 1, 5, '', 0, 1, '', 0, 0, 0, 0),
(246, 'Feedback', '', '', '', '', '', '', 2, 'feedback', 'ru/feedback/', 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, '', 2, 0, '2016-05-24 20:01:38', '2016-05-24 20:07:32', 1, 6, '', 0, 1, '', 0, 0, 0, 0);

DROP TABLE IF EXISTS pm_tags;
CREATE TABLE `pm_tags` (
  `tag_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`tag_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_templates;
CREATE TABLE `pm_templates` (
  `template_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL DEFAULT '',
  `filename` varchar(128) NOT NULL DEFAULT '',
  `containers` varchar(255) NOT NULL DEFAULT '',
  `handlers_install` varchar(255) NOT NULL DEFAULT '',
  `handlers_init` varchar(255) NOT NULL DEFAULT '',
  `handlers` varchar(255) NOT NULL DEFAULT '',
  `tpl_alias` varchar(32) NOT NULL DEFAULT '',
  `modification_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`template_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_templates` VALUES
(1, 'default', 'default', 'main, additional_1, additional_2, additional_3, additional_4', 'main(html_editor)', '', 'main_menu|logout', 'default', '2010-09-25 07:06:50'),
(3, '404', '404', 'main, footer', 'main(html_editor)', '', 'main_menu', '404', '0000-00-00 00:00:00');

DROP TABLE IF EXISTS pm_toc;
CREATE TABLE `pm_toc` (
  `toc_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `s_id` int(11) unsigned NOT NULL DEFAULT '0',
  `container` varchar(32) NOT NULL DEFAULT '',
  `sort_order` int(11) unsigned NOT NULL DEFAULT '0',
  `handler` varchar(32) NOT NULL DEFAULT '',
  `content_id` int(11) unsigned NOT NULL DEFAULT '0',
  `enabled` int(1) unsigned NOT NULL DEFAULT '0',
  `tpl_alias` varchar(32) NOT NULL DEFAULT '',
  `inheritable` int(1) unsigned NOT NULL DEFAULT '0',
  `cache_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`toc_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_toc` VALUES
(3, 1, 'main', 0, 'shop', 0, 0, 'categories', 0, 4),
(5, 240, 'main', 0, 'shop', 0, 1, 'shop', 0, 8),
(7, 1, 'main', 10, 'shop', 0, 0, 'basket', 0, 1),
(8, 1, 'main', 0, 'shop', 0, 0, 'shop', 0, 1),
(9, 241, 'main', 0, 'html_editor', 2, 1, '', 0, 2),
(10, 242, 'main', 0, 'html_editor', 3, 1, '', 0, 2),
(12, 244, 'main', 0, 'html_editor', 5, 0, '', 0, 0),
(13, 245, 'main', 0, 'html_editor', 6, 0, '', 0, 0),
(14, 246, 'main', 0, 'html_editor', 7, 0, '', 0, 0),
(15, 245, 'main', 0, 'registration', 0, 1, '', 0, 0),
(16, 246, 'main', 0, 'feedback', 0, 1, '', 0, 0),
(17, 244, 'main', 0, 'news', 0, 1, '', 0, 0),
(18, 1, 'main', 0, 'html_editor', 8, 0, '', 0, 3),
(19, 1, 'main', 0, 'banners', 0, 1, '', 0, 1);

DROP TABLE IF EXISTS pm_toc_inh_exclusions;
CREATE TABLE `pm_toc_inh_exclusions` (
  `toc_id` int(11) unsigned NOT NULL DEFAULT '0',
  `s_id` int(11) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_user_permissions;
CREATE TABLE `pm_user_permissions` (
  `permission_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(5) unsigned NOT NULL DEFAULT '0',
  `site_id` varchar(64) NOT NULL DEFAULT '',
  `plugin` varchar(64) NOT NULL DEFAULT '',
  `type` enum('site','plugin','action','structure','group') NOT NULL DEFAULT 'site',
  `object` varchar(64) NOT NULL DEFAULT '',
  `value` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_user_sessions;
CREATE TABLE `pm_user_sessions` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(5) unsigned NOT NULL DEFAULT '0',
  `session_id` varchar(32) NOT NULL DEFAULT '',
  `login_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_refresh` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_forum` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_user_sessions` VALUES
(1, 1, 'cdc4316e0acd5643677245a99dff57ee', '2016-03-20 16:37:50', '2016-03-20 16:38:58', '0000-00-00 00:00:00', '91.227.180.139'),
(2, 1, '5e3ddfe1c3647408670c7b5c105a12fd', '2016-03-26 18:37:37', '2016-04-28 21:07:53', '0000-00-00 00:00:00', '127.0.0.1'),
(3, 1, '451b7c8644cdbdd2446e9d5026423150', '2016-04-28 21:18:29', '2016-04-28 21:18:29', '0000-00-00 00:00:00', '127.0.0.1'),
(4, 1, '3caa542d93c94795dea7978a60ca00ea', '2016-04-28 21:19:28', '2016-05-10 17:40:56', '0000-00-00 00:00:00', '127.0.0.1'),
(5, 1, '3bc53109de736202313f19ecdb573653', '2016-05-24 19:36:31', '2016-05-26 18:05:32', '0000-00-00 00:00:00', '91.227.180.139');

DROP TABLE IF EXISTS pm_users;
CREATE TABLE `pm_users` (
  `uid` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(32) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `post` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `country` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `info` mediumtext NOT NULL,
  `subscribe` int(1) unsigned NOT NULL DEFAULT '0',
  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valid_account` int(1) unsigned NOT NULL DEFAULT '0',
  `access_level` int(2) unsigned NOT NULL DEFAULT '0',
  `site_access` mediumtext NOT NULL,
  `cms_structure_access` mediumtext NOT NULL,
  `cms_plugins_access` varchar(255) NOT NULL DEFAULT '',
  `member_of_groups` varchar(255) NOT NULL DEFAULT '',
  `member_of_network` int(11) unsigned NOT NULL DEFAULT '0',
  `networks_access` varchar(255) NOT NULL DEFAULT '',
  `last_name` varchar(255) NOT NULL DEFAULT '',
  `patr` varchar(255) NOT NULL DEFAULT '',
  `address` mediumtext NOT NULL,
  `icq` varchar(255) NOT NULL DEFAULT '',
  `skype` varchar(255) NOT NULL DEFAULT '',
  `company` varchar(255) NOT NULL DEFAULT '',
  `position` varchar(255) NOT NULL DEFAULT '',
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `sex` int(3) NOT NULL DEFAULT '0',
  `avatar` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1600 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pm_users` VALUES
(1, 'admin', '9dbb300e28bc21c8dab41b01883918eb', 'ibolosig@gmail.com', 'admin', '', '', '', '', '', 0, '2011-02-25 17:43:27', 1, 90, '', '', '', '', 0, '', 'admin', '', '', '', '', '', '', '2011-02-25', 0, '');

DROP TABLE IF EXISTS pm_users_iplog;
CREATE TABLE `pm_users_iplog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `login_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_refresh` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pm_words;
CREATE TABLE `pm_words` (
  `word_id` int(11) NOT NULL AUTO_INCREMENT,
  `word_ru` varchar(255) NOT NULL DEFAULT '',
  `word_ua` varchar(255) NOT NULL DEFAULT '',
  `word_en` varchar(255) NOT NULL DEFAULT '',
  `count_view_ru` int(11) NOT NULL DEFAULT '0',
  `count_view_ua` int(11) NOT NULL DEFAULT '0',
  `count_view_en` int(11) NOT NULL DEFAULT '0',
  `enabled` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`word_id`)
) ENGINE=MyISAM AUTO_INCREMENT=197 /*!40101 DEFAULT CHARSET=utf8 */;

